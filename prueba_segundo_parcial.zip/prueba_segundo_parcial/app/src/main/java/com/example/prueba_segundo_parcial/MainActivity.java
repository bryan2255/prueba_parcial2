package com.example.prueba_segundo_parcial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.prueba_segundo_parcial.db.DbHelper;

public class MainActivity extends AppCompatActivity {
    private DbHelper databaseHelper;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnIrOtraActivity = findViewById(R.id.btn_base_cursos);
        
        View btnRedirect = findViewById(R.id.btn_redireccionar);
        btnRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.espe.edu.ec/#";

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

        databaseHelper = new DbHelper(this, "mydatabasecursos", null);
        database = databaseHelper.getWritableDatabase();

        // Aquí puedes realizar operaciones con la base de datos, como insertar, consultar, actualizar o eliminar datos.
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        database.close();
    }

    }
